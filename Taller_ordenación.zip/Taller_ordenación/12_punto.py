
def bucketSort(lista):
    largest = max(lista)
    length = len(lista)
    size = largest/length
 
    # Se crean los Buckets
    buckets = [[] for i in range(length)]
 
    # Se ordenan los Buckets   
    for i in range(length):
        index = int(lista[i]/size)
        if index != length:
            buckets[index].append(lista[i])
        else:
            buckets[length - 1].append(lista[i])
 
    # Se ordenan los Buckets individialmente
    for i in range(len(lista)):
        buckets[i] = sorted(buckets[i])
 
    # Se arregla lista organizada
    result = []
    for i in range(length):
        result = result + buckets[i]
    return result
 
lista = [9,7,3,56,741,8,4,5,75,4,7,74,45,5,8,74,8,]
print(bucketSort(lista))