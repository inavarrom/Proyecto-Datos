def DeLaBurbuja(list):
    for numPasada in range(len(list)-1,0,-1):
        for i in range(numPasada):
            if list[i]>list[i+1]:
                temp = list[i]
                list[i] = list[i+1]
                list[i+1] = temp

                print(list)
                
list = [47,3,21,32,56,92]

DeLaBurbuja(list)

