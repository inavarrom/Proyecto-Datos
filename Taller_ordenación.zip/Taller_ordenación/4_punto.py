# Shell sort in python


def shellSort(array, n):
    
    interval = n // 2
    while interval > 0:
        for i in range(interval, n):
            temp = array[i]
            j = i
            while j >= interval and array[j - interval] > temp:
                array[j] = array[j - interval]
                j -= interval

            array[j] = temp
        interval //= 2
        print(data)

data = [8, 43, 17, 6, 40, 16, 18, 97, 11, 7]
size = len(data)
shellSort(data, size)

