def elecciones_presidenciales (list):
    voto = list
    voto.sort
    count_0 = 0
    count_1 = 0
    count_2 = 0
    count_3 = 0
    count_4 = 0

    for items in voto:
        if items == 0:
            count_0 += 1
        if items == 1:
            count_1 += 1
        if items == 2:
            count_2 += 1
        if items == 3:
            count_3 += 1
        if items == 4:
            count_4 += 1
    
    votos_contados = {"0":count_0, "1":count_1, "2":count_2, "3":count_3, "4":count_4}
    candidato_ganador = max(votos_contados,key=votos_contados.get)
    print("El ganador es el candidato # ",candidato_ganador)

lista_prueba = [0,0,0,0,1,1,1,2,2,3,3,3,4]
elecciones_presidenciales(lista_prueba)