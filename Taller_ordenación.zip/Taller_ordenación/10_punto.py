def busqueda_matriz(n,mat):
    matrix = mat
    if len(matrix) ==0:
        print("Matriz vacia, porfa colabore")
        return
    for i in range(len(matrix)):
        for j in range(len(matrix[i])):
            if(matrix[i][j] == n):
                print ("yes")
                return
    print("no")

#Prueba
mat = [[10, 20, 30, 40], [15, 25, 35, 45],[27, 29, 37, 48],[32, 33, 39, 50]]
busqueda_matriz(0,mat)
mate = []
busqueda_matriz(5, mate)