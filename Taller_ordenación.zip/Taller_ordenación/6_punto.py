futbolistasTup = [(1, "Casillas"), (15, "Ramos"), (3, "Pique"), (5, "Puyol"), (11, "Capdevila"),  (14, "Xabi Alonso"), (16, "Busquets"), (8, "Xavi Hernandez"), (18, "Pedrito"), (6, "Iniesta"), (7, "Villa")]
futbolistasTup.sort(key=lambda futbolista: futbolista[0])
print(futbolistasTup)



inventosTup = [(71, "El bastón inteligente"), (50, "Cirugía virtual"), (15, "AirPods Pro"), (30, "Pantallas de 8K"), (70, "La prótesis de mano robot"), (60, "Entregas a domicilio automáticas"), (1, "El basurero inteligente")]
inventosTup.sort(key=lambda inventos: inventos[0])
print(inventosTup)