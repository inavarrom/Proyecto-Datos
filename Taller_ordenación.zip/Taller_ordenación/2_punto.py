#segundo punto

Lista = [4,5,7,8,9,10,11,15,19,19] #cualquier lista ordenada

ListaR = [] #creamos una nueva lista en la que no estarán números repetidos
 
for element in Lista: #para el elemento en la lista
    if element not in ListaR: #si el elemento no está en la lista sin números repetidos 
        ListaR.append(element) #insertar el elemento en la lista sin números repetidos

print(ListaR) #imprimir la lista sin números repetidos