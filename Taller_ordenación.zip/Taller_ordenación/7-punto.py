Lista = [-92,-12,-11,-25,-9,-5,-11,-17,-19,-15] #cualquier lista

ListaR = [] #creamos una nueva lista en la que estarán los números negativos
 
for element in Lista: #para el elemento en la lista
    if element < 0: #si el elemento es un número negativo 
        ListaR.append(element) #insertar el elemento en la lista 

print(ListaR) #imprimir la lista de los números negtivos 
