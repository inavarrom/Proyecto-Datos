Lista = [4,7,11,4,9,5,11,7,3,5] #cualquier lista

ListaR = [] #creamos una nueva lista en la que no estarán números repetidos
 
for element in Lista: #para el elemento en la lista
    if element not in ListaR: #si el elemento no está en la lista sin números repetidos 
        ListaR.append(element) #insertar el elemento en la lista sin números repetidos

print(ListaR) #imprimir la lista sin números repetidos